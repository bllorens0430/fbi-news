Notes:
1. Secure login seems ok
2. Add news suffers from Sql injection attacks.