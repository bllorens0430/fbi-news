Notes:
1. Secure login seems ok
2. All queries taking input are changed to pdo.