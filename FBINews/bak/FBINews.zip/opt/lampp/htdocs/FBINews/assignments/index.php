<?php

header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); // Date in the past


require("../check.php");
		
if(isset($_POST['Add']))
{
	$varCrimeClassification = $_POST['crime_classification'];
	$varCatName = $_POST['cat_name'];
	$varCatExplanation = $_POST['cat_explanation'];
	$errorMessage = "";
	
//	require("dbo.php");	  
	
	$sql = "INSERT INTO crime_category (crime_classification, cat_name, cat_explanation) 
	VALUES (:crime_classification, :cat_name, :cat_explanation)";
	  
	$array_param=array(':crime_classification'=>addslashes($varCrimeClassification), 
	':cat_name'=>addslashes($varCatName),
	':cat_explanation'=>addslashes($varCatExplanation));
	  
	$sth = $db->prepare($sql);
	$sth->execute($array_param);
//	$dbh=null;  
}

if(isset($_POST['Update']))
{	
  $varCatNumber = $_POST['cat_number'];
  $varCrimeClassification = $_POST['crime_classification'];
  $varCatName = $_POST['cat_name'];
  $varCatExplanation = $_POST['cat_explanation'];
  $errorMessage = "";
	
  $sql = "UPDATE crime_category SET crime_classification=:crime_classification, cat_name=:cat_name,
  cat_explanation=:cat_explanation
  WHERE cat_number=:cat_number";

  $array_param=array(':cat_name'=>addslashes($varCatName), 
  ':crime_classification'=>intval(addslashes($varCrimeClassification)), 
  ':cat_explanation'=>addslashes($varCatExplanation),
  ':cat_number' =>intval(addslashes($varCatNumber)));
  
  $sth = $db->prepare($sql);
  $sth->execute($array_param);
//  $dbh=null;  
}
?> 

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>View News</title>
</head>

<body>
<table>
<tr>
<td>
<form action="add_cat.php">
  <input type="submit" value="Add">
</form>
</td>
<td>
<form action="../view.php">
  <input type="submit" value="News">
</form>
</td>
<td>
 <form action="../logout.php">
  <input type="submit" value="Logout">
</form>
</td>
</tr>
</table>
<table border="1">
  <?php
  //include("dbo.php");
  
  $sql="SELECT * FROM crime_category";
          
  foreach ($db->query($sql) as $test)
  {
	  $id=$test['cat_number'];
  
      echo "<tr align='center'>";	
      echo"<td><font color='black'>" .$id."</font></td>";
      echo"<td><font color='black'>" . $test['crime_classification'] . "</font></td>";
      echo"<td><font color='black'>" . $test['cat_name'] . "</font></td>";
      echo"<td> <a href ='update_cat.php?cat_number=$id'>Edit</a>";
      echo"<td> <a href ='del_cat.php?cat_number=$id'><center>Delete</center></a>";
                          
      echo "</tr>";
  }
  $db=null;
  ?>
</table>

</body>
</html>

