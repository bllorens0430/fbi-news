<footer class="footer">
      <div class="container">
        <p class="text-muted"><a href="mailto:xinwenfu@gmail.com">Contact</a> | &copy; 2015 <a href="http://www.cs.uml.edu/~xinwenfu/">Xinwen Fu</a>  | James Palmer | Brea Llorens<a rel="license" href="http://creativecommons.org/licenses/by/3.0/"></a></p>
      </div>
    </footer>
